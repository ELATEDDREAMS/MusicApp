package com.exmple.android.musicapp;

import android.app.ActionBar;
import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        //Find view that shows playlist button
        Button Playlist = (Button) findViewById(R.id.plButton);

        //Set clickListener on that view
        Playlist.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                //Create new intent to open playlistActivity
                Intent plButtonIntent = new Intent(MainActivity.this,
                        PlaylistActivity.class);

                //Start Playlist Activity
                startActivity(plButtonIntent);

            }
        });

    }
}