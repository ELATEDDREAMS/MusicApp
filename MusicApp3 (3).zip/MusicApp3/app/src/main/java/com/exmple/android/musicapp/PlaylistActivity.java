package com.exmple.android.musicapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.widget.ListView;


import java.util.ArrayList;

public class PlaylistActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_playlist);

        //Create an array of words
        ArrayList<Word> words = new ArrayList<Word>();
        words.add(new Word("The All American Rejects","Affection"));
        words.add(new Word("Blink 182","Adams Song"));
        words.add(new Word("Brian Crain","Solitary Hill"));
        words.add(new Word("Helen Jane Long","Swiftly"));
        for (int index = 0; index < words.size(); index++);
        WordAdapter adapter = new WordAdapter(this, words);
        ListView listView = (ListView)findViewById(R.id.store);
        listView.setAdapter(adapter);

}
}