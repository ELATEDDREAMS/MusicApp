package com.exmple.android.musicapp;




import android.view.View;

public class PlaylistClickListener implements View.OnClickListener {


    @Override
    public void onClick(View view) {

    }
}
