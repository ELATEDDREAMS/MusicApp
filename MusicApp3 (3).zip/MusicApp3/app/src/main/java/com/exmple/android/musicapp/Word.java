package com.exmple.android.musicapp;

public class Word {

    //Artist Name
    private String mArtist;

    //Artist Song
    private String mSong;

    public Word(String Artist, String Song){
        mArtist= Artist;
        mSong = Song;

    }

    public String getArtist() {
        return mArtist;
    }

    public String getSong() {
        return mSong;
    }
}
